<?php
// cancelled_panel.php - "Recently Cancelled" table showing WHO cancelled and WHY.
// Used by supervisor_dashboard.php (scoped to one course) and admin_dashboard.php (all courses).
require_once __DIR__ . "/layout.php";

function render_cancelled_panel(mysqli $c, ?int $courseScope, string $seeAllUrl): void
{
    $where = "a.status = 'cancelled'";
    $types = '';
    $p = [];
    if ($courseScope) {
        $where .= " AND a.course_id = ?";
        $types = 'i';
        $p[] = $courseScope;
    }

    $rows = db_rows($c, "
        SELECT a.id, a.user_id, a.reference_no, a.appointment_date, a.appointment_time, a.cancel_reason, a.updated_at,
               u.full_name student_name, u.student_id, sv.name service_name, co.name course_name,
               h.changed_by, h.created_at cancelled_at, cu.full_name by_name, cu.role by_role
        FROM appointments a
        JOIN users u      ON u.id  = a.user_id
        JOIN services sv  ON sv.id = a.service_id
        JOIN courses co   ON co.id = a.course_id
        LEFT JOIN appointment_history h ON h.id = (
              SELECT MAX(h2.id) FROM appointment_history h2
              WHERE h2.appointment_id = a.id AND h2.new_status = 'cancelled')
        LEFT JOIN users cu ON cu.id = h.changed_by
        WHERE $where
        ORDER BY COALESCE(h.created_at, a.updated_at) DESC
        LIMIT 10", $types, $p);

    echo '<div class="card"><h3>Recently Cancelled</h3>';

    if (!$rows) {
        echo '<div class="empty">No cancelled appointments.</div></div>';
        return;
    }

    echo '<div class="table-wrap"><table class="table"><thead><tr>'
        . '<th>Reference</th><th>Student</th>' . ($courseScope ? '' : '<th>Course</th>')
        . '<th>Service</th><th>Appointment</th><th>Cancelled by</th><th>Reason</th><th>When</th>'
        . '</tr></thead><tbody>';

    foreach ($rows as $r) {
        if ($r['by_name'] === null) {
            $who = '<span class="muted">Unknown</span>';
        } elseif ((int)$r['changed_by'] === (int)$r['user_id']) {
            $who = e($r['by_name']) . '<br><small>Student (self-cancelled)</small>';
        } else {
            $who = e($r['by_name']) . '<br><small>' . e(ucfirst($r['by_role'])) . '</small>';
        }
        $when = $r['cancelled_at'] ?: $r['updated_at'];

        echo '<tr><td><strong>' . e($r['reference_no']) . '</strong></td>'
            . '<td>' . e($r['student_name']) . '<br><small>' . e($r['student_id']) . '</small></td>'
            . ($courseScope ? '' : '<td>' . e($r['course_name']) . '</td>')
            . '<td>' . e($r['service_name']) . '</td>'
            . '<td>' . e(fmt_date($r['appointment_date'])) . '<br><small>' . e(fmt_time($r['appointment_time'])) . '</small></td>'
            . '<td>' . $who . '</td>'
            . '<td>' . ($r['cancel_reason'] ? e($r['cancel_reason']) : '<span class="muted">—</span>') . '</td>'
            . '<td>' . e(date('M j, h:i A', strtotime($when))) . '</td></tr>';
    }

    echo '</tbody></table></div>'
        . '<p style="margin-top:10px"><a href="' . e($seeAllUrl) . '">See all cancelled appointments →</a></p></div>';
}
